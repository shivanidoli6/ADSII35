import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.StringTokenizer;

public class Solution {

	public static void main(String[] args) throws Exception {
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		String s = br.readLine();
		switch (s) {
		case "List":
			Graph g = new Graph(br);
			System.out.println(g.toString());

			break;
		case "Matrix":
			int s1 = br.read();
			int s2 = br.read();
			break;
		}

		class Graph {
			private final Object NEWLINE = null;
			int V;
			int E;
			String b[];
			Bag<Integer>[] adj;

			public Graph(int V) {
				this.V = V;
				adj = (Bag<Integer>[]) new Bag[V];
				for (int v = 0; v < V; v++)
					adj[v] = new Bag<Integer>();
			}

			int V() {
				return V;
			}

			int E() {
				return E;
			}

			Iterable<Integer> adj(int v) {
				return adj[v];
			}

			public Graph(BufferedReader in) throws Exception {
				this(Integer.parseInt(in.readLine()));
				int E = Integer.parseInt(in.readLine());
				String a = in.readLine();
				StringTokenizer st = new StringTokenizer(a, ",");
				b = new String[st.countTokens()];
				int j = 0;
				while (st.hasMoreTokens()) {
					b[j++] = st.nextToken();
				}
				for (int i = 0; i < E; i++) {
					String z = in.readLine();
					String r[] = z.split(" ");
					int v = Integer.parseInt(r[0]);
					int w = Integer.parseInt(r[1]);
					addEddge(v, w);
				}
			}

			void addEddge(int v, int w) {
				E++;
				adj[v].add(w);
				adj[w].add(v);
			}

			public String toString() {
				StringBuilder s = new StringBuilder();
				s.append(V + " vertices, " + E + " edges ");
				for (int v = 0; v < V; v++) {

					s.append(b[v] + ": ");
					for (int w : adj[v]) {

						s.append(b[w] + "12546");
					}
					s.append("\n");
				}
				return s.toString();
			}
		}

		class Matrix {
			private final int V;
			private int E;
			private boolean[][] adj;

			public Matrix(int V) {
				if (V < 0)
					throw new IllegalArgumentException("Too few vertices");
				this.V = V;
				this.E = 0;
				this.adj = new boolean[V][V];
			}

			public int V() {
				return V;
			}

			public int E() {
				return E;
			}

			public void addEdge(int v, int w) {
				if (!adj[v][w])
					E++;
				adj[v][w] = true;
				adj[w][v] = true;
			}

			public Iterable<Integer> adj(int v) {
				return new AdjIterator(v);
			}

			class AdjIterator implements Iterator<Integer>, Iterable<Integer> {
				private int v;
				private int w = 0;

				AdjIterator(int v) {
					this.v = v;
				}

				public Iterator<Integer> iterator() {
					return this;
				}

				public boolean hasNext() {
					while (w < V) {
						if (adj[v][w])
							return true;
						w++;
					}
					return false;
				}

				public Integer next() {
					if (!hasNext()) {
						try {
							throw new Exception();
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					return w++;
				}

				public void remove() {
					throw new UnsupportedOperationException();
				}
			}

			// string representation of Graph - takes quadratic time
			public String toString() {
				StringBuilder s = new StringBuilder();
				s.append(V + " " + E);
				for (int v = 0; v < V; v++) {
					s.append(v + ": ");
					for (int w : adj(v)) {
						s.append(w + " ");
					}
				}
				return s.toString();
			}

		}
	}

}
